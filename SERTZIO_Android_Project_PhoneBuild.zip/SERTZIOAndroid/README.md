# SERTZIO Ticket Assistant Android project

Starter native Android Studio project (Kotlin WebView shell with app-local HTML assets).

## Build an APK
1. Open this project folder in Android Studio.
2. Allow Gradle sync (internet may be required to download Android Gradle Plugin).
3. Build > Build APK(s).
4. The debug APK will be in `app/build/outputs/apk/debug/`.

Current app is a local prototype: passenger data and release timer use browser local storage inside the WebView. It does not connect to Lakshadweep IRCTC, refresh/submit booking requests, select live seats, or perform payments. Only store ID last-four digits; do not store full Aadhaar, OTPs, or payment data.
